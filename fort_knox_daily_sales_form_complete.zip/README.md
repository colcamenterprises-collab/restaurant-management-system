# Fort Knox Daily Sales & Stock Form - Complete Export

## Overview
This export contains the complete Fort Knox locked form system for Smash Brothers Burgers daily sales and stock management. All files are locked under Cam's direct approval and follow exact specifications.

## 🔒 LOCKED SYSTEM STRUCTURE

### Form Components (13 Sections in Exact Order):
1. **Shift Information** - Basic shift details
2. **Sales Information** - Sales breakdown including Aroi Dee Sales (approved)
3. **Wages & Staff Payments** - Staff payment tracking
4. **Shopping & Expenses** - Purchase and expense management
5. **Cash Management** - Cash flow with Burger Buns & Meat Count
6. **Burger Buns & Meat Count** - Under Cash Management section
7. **Drink Stock** - Beverage inventory
8. **Fresh Food Stock** - Fresh ingredients tracking
9. **Frozen Food** - Frozen items inventory
10. **Shelf Items** - Dry goods and shelf-stable items
11. **Kitchen Items** - Kitchen supplies
12. **Packaging Items** - Packaging materials
13. **Total Summary** - Final calculations and totals

## 📁 FILE STRUCTURE

### Frontend Files
- **`client/src/pages/DailyStockSalesSchema.tsx`** - Main Fort Knox form implementation
- **`client/src/pages/DailyStockSales.tsx`** - Alternative form view
- **`client/src/pages/DailySalesAndStockForm.tsx`** - Additional form component
- **`client/src/components/Layout.tsx`** - Main layout wrapper
- **`client/src/components/ui/`** - Complete shadcn/ui component library

### Backend Files
- **`server/routes.ts`** - Main API routes including POST /api/daily-stock-sales
- **`server/storage.ts`** - Database storage layer
- **`server/emailService.ts`** - Email functionality
- **`server/workingEmailService.ts`** - Working email implementation
- **`shared/schema.ts`** - Database schema definitions

## 🚫 RESTRICTIONS
- **NO field additions/removals** without Cam approval
- **NO section reordering** - exact 13-section structure locked
- **NO schema modifications** - follows Pydantic structure exactly
- **Email target locked**: smashbrothersburgersth@gmail.com

## ✅ APPROVED FEATURES
- **Aroi Dee Sales** field (mandatory approved sales channel)
- **Burger Buns & Meat Count** under Cash Management section
- **Snake_case field names** matching Pydantic schema
- **Minimal UI design** with Poppins font
- **Auto-calculations** for total sales

## 🔧 TECHNICAL DETAILS
- **Frontend**: React + TypeScript + shadcn/ui + Tailwind CSS
- **Backend**: Node.js + Express + Drizzle ORM + PostgreSQL
- **Form Validation**: React Hook Form + Zod validation
- **Email System**: Ready for Gmail integration

## 📧 EMAIL INTEGRATION
System configured for automatic email notifications to:
- **Target**: smashbrothersburgersth@gmail.com
- **Format**: Professional HTML + PDF attachment
- **Trigger**: Every completed form submission

## 🛡️ DATA INTEGRITY
- All calculations bulletproof with proper number handling
- Form submission error handling with retry logic
- Database transaction safety
- Input sanitization and validation

## 🚀 DEPLOYMENT STATUS
- Form location: `/daily-stock-sales`
- API endpoint: `POST /api/daily-stock-sales`
- Status: **Production Ready**
- Last update: August 4, 2025
- Version: Fort Knox Locked

---
**⚠️ IMPORTANT**: This system is locked under Cam's approval. All modifications require explicit authorization. Contact Cam for any change requests.