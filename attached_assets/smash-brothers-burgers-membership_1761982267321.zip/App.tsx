
import React, { useState, useCallback } from 'react';
import { Member, NewMember } from './types';
import AdminDashboard from './components/AdminDashboard';
import RegistrationForm from './components/RegistrationForm';
import { addMemberToLoyverse } from './services/loyverseService';

// Mock initial data
const initialMembers: Member[] = [
    { id: '123456', name: 'John Doe', email: 'john.doe@example.com', phone: '0812345678', totalSpend: 1550.00 },
    { id: '789012', name: 'Jane Smith', email: 'jane.smith@example.com', phone: '0887654321', totalSpend: 2300.50 },
    { id: '345678', name: 'Mike Johnson', email: 'mike.j@example.com', phone: '0912345678', totalSpend: 875.00 },
];

const App: React.FC = () => {
    const [members, setMembers] = useState<Member[]>(initialMembers);
    const [view, setView] = useState<'register' | 'dashboard'>('dashboard');

    const generateUniqueId = useCallback(() => {
        let newId: string;
        do {
            newId = Math.floor(100000 + Math.random() * 900000).toString();
        } while (members.some(m => m.id === newId));
        return newId;
    }, [members]);

    const handleRegisterMember = async (newMemberData: NewMember): Promise<Member> => {
        const newId = generateUniqueId();
        const newMember: Member = {
            id: newId,
            ...newMemberData,
            totalSpend: 0
        };
        
        // Simulate API call to Loyverse
        await addMemberToLoyverse(newMember);

        setMembers(prevMembers => [newMember, ...prevMembers]);
        return newMember;
    };
    
    const handleAddSpend = (memberId: string, amount: number) => {
        setMembers(prevMembers =>
            prevMembers.map(member =>
                member.id === memberId
                    ? { ...member, totalSpend: member.totalSpend + amount }
                    : member
            )
        );
    };

    const toggleView = () => {
        setView(prevView => (prevView === 'dashboard' ? 'register' : 'dashboard'));
    };

    return (
        <div className="min-h-screen bg-gray-900 text-gray-100 p-4 sm:p-6 lg:p-8">
            <div className="max-w-7xl mx-auto">
                <header className="flex justify-between items-center mb-8">
                    <div className="flex items-center space-x-4">
                        <svg className="w-12 h-12 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.657 7.343A8 8 0 0117.657 18.657z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.879 16.121A3 3 0 1014.12 11.88a3 3 0 00-4.242 4.242z" /></svg>
                        <h1 className="font-display text-4xl tracking-wider text-white">Smash Brothers Burgers</h1>
                    </div>
                    <button 
                        onClick={toggleView}
                        className="font-display text-lg bg-yellow-400 text-gray-900 px-6 py-2 rounded-md hover:bg-yellow-300 transition-colors duration-300"
                    >
                        {view === 'dashboard' ? 'New Member Form' : 'Admin Dashboard'}
                    </button>
                </header>

                <main>
                    {view === 'dashboard' ? (
                        <AdminDashboard members={members} onAddSpend={handleAddSpend} />
                    ) : (
                        <RegistrationForm onRegister={handleRegisterMember} />
                    )}
                </main>
            </div>
        </div>
    );
};

export default App;
