
import { Member } from '../types';

/**
 * Simulates adding a new member to the Loyverse CRM via API.
 * In a real application, this would be an actual HTTP request.
 * @param member The member data to add.
 * @returns A promise that resolves on success.
 */
export const addMemberToLoyverse = (member: Member): Promise<void> => {
  console.log('Syncing member to Loyverse:', member);
  
  return new Promise((resolve, reject) => {
    // Simulate network delay
    setTimeout(() => {
      // Simulate a potential failure rate (e.g., 10% chance)
      if (Math.random() < 0.9) {
        console.log('Successfully synced to Loyverse.');
        resolve();
      } else {
        console.error('Failed to sync to Loyverse.');
        reject(new Error('API Error: Could not sync member to Loyverse.'));
      }
    }, 1500);
  });
};
