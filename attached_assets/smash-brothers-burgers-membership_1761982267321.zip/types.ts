
export interface Member {
  id: string;
  name: string;
  email: string;
  phone: string;
  totalSpend: number;
}

export interface NewMember {
  name: string;
  email: string;
  phone: string;
}
