
import React, { useState } from 'react';
import { Member } from '../types';
import MemberList from './MemberList';
import MemberCard from './MemberCard';
import AddSpendModal from './AddSpendModal';

interface AdminDashboardProps {
    members: Member[];
    onAddSpend: (memberId: string, amount: number) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ members, onAddSpend }) => {
    const [selectedMember, setSelectedMember] = useState<Member | null>(null);
    const [isCardModalOpen, setCardModalOpen] = useState(false);
    const [isSpendModalOpen, setSpendModalOpen] = useState(false);

    const handleViewCard = (member: Member) => {
        setSelectedMember(member);
        setCardModalOpen(true);
    };

    const handleOpenAddSpend = (member: Member) => {
        setSelectedMember(member);
        setSpendModalOpen(true);
    };
    
    const handleCloseModals = () => {
        setCardModalOpen(false);
        setSpendModalOpen(false);
        setSelectedMember(null);
    };

    const handleConfirmAddSpend = (amount: number) => {
        if (selectedMember && amount > 0) {
            onAddSpend(selectedMember.id, amount);
        }
        handleCloseModals();
    };

    return (
        <div className="bg-gray-800 p-6 rounded-lg shadow-2xl">
            <h2 className="font-display text-4xl text-yellow-400 mb-6">Members Dashboard</h2>
            <MemberList members={members} onViewCard={handleViewCard} onAddSpend={handleOpenAddSpend} />

            {isCardModalOpen && selectedMember && (
                 <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" onClick={handleCloseModals}>
                    <div className="relative" onClick={e => e.stopPropagation()}>
                         <button onClick={handleCloseModals} className="absolute -top-4 -right-4 bg-white text-gray-900 rounded-full h-10 w-10 flex items-center justify-center shadow-lg hover:bg-gray-200 transition-colors z-10">
                            &times;
                        </button>
                        <MemberCard member={selectedMember} />
                    </div>
                </div>
            )}
            
            {isSpendModalOpen && selectedMember && (
                <AddSpendModal 
                    member={selectedMember} 
                    onClose={handleCloseModals}
                    onConfirm={handleConfirmAddSpend}
                />
            )}
        </div>
    );
};

export default AdminDashboard;
