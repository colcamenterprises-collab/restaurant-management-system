
import React from 'react';
import { Member } from '../types';
import { CardIcon, MoneyIcon } from './icons';

interface MemberListProps {
    members: Member[];
    onViewCard: (member: Member) => void;
    onAddSpend: (member: Member) => void;
}

const MemberList: React.FC<MemberListProps> = ({ members, onViewCard, onAddSpend }) => {
    return (
        <div className="overflow-x-auto">
            <table className="min-w-full bg-gray-900 rounded-lg">
                <thead>
                    <tr className="border-b border-gray-700">
                        <th className="p-4 text-left font-display text-lg tracking-wider text-yellow-400">Name</th>
                        <th className="p-4 text-left font-display text-lg tracking-wider text-yellow-400">Member ID</th>
                        <th className="p-4 text-left font-display text-lg tracking-wider text-yellow-400 hidden md:table-cell">Contact</th>
                        <th className="p-4 text-right font-display text-lg tracking-wider text-yellow-400">Total Spend (THB)</th>
                        <th className="p-4 text-center font-display text-lg tracking-wider text-yellow-400">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {members.length === 0 ? (
                        <tr>
                           <td colSpan={5} className="text-center p-8 text-gray-500">No members found.</td>
                        </tr>
                    ) : members.map((member) => (
                        <tr key={member.id} className="border-b border-gray-800 hover:bg-gray-700/50 transition-colors">
                            <td className="p-4 font-medium">{member.name}</td>
                            <td className="p-4 text-gray-400 font-mono">{member.id}</td>
                            <td className="p-4 text-gray-400 hidden md:table-cell">
                                <div className="flex flex-col">
                                    <span>{member.email}</span>
                                    <span className="text-sm text-gray-500">{member.phone}</span>
                                </div>
                            </td>
                            <td className="p-4 text-right font-medium text-green-400 font-mono">
                                {member.totalSpend.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </td>
                            <td className="p-4">
                                <div className="flex justify-center items-center space-x-2">
                                    <button 
                                        onClick={() => onViewCard(member)}
                                        title="View Card"
                                        className="p-2 rounded-full text-gray-400 hover:bg-gray-600 hover:text-white transition-colors"
                                    >
                                        <CardIcon className="w-5 h-5" />
                                    </button>
                                    <button 
                                        onClick={() => onAddSpend(member)}
                                        title="Add Spend"
                                        className="p-2 rounded-full text-gray-400 hover:bg-gray-600 hover:text-white transition-colors"
                                    >
                                        <MoneyIcon className="w-5 h-5" />
                                    </button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default MemberList;
