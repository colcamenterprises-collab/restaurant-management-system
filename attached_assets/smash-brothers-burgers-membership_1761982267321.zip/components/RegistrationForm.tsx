
import React, { useState } from 'react';
import { NewMember, Member } from '../types';
import MemberCard from './MemberCard';
import { UserIcon, EmailIcon, PhoneIcon } from './icons';

interface RegistrationFormProps {
    onRegister: (newMember: NewMember) => Promise<Member>;
}

type Status = 'idle' | 'submitting' | 'success' | 'error';

const RegistrationForm: React.FC<RegistrationFormProps> = ({ onRegister }) => {
    const [formData, setFormData] = useState<NewMember>({ name: '', email: '', phone: '' });
    const [status, setStatus] = useState<Status>('idle');
    const [error, setError] = useState<string | null>(null);
    const [registeredMember, setRegisteredMember] = useState<Member | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.name || !formData.email || !formData.phone) {
            setError("All fields are required.");
            return;
        }
        setError(null);
        setStatus('submitting');
        try {
            const member = await onRegister(formData);
            setRegisteredMember(member);
            setStatus('success');
            setFormData({ name: '', email: '', phone: '' });
        } catch (err) {
            setStatus('error');
            setError('Failed to register member. Please try again.');
            console.error(err);
        }
    };
    
    if (status === 'success' && registeredMember) {
        return (
            <div className="bg-gray-800 p-8 rounded-lg shadow-2xl max-w-lg mx-auto text-center">
                <h2 className="font-display text-4xl text-green-400 mb-4">Welcome!</h2>
                <p className="text-gray-300 mb-6">Your registration is complete. Here is your digital membership card. Please save it or take a screenshot.</p>
                <div className="scale-110">
                    <MemberCard member={registeredMember} />
                </div>
                 <button 
                    onClick={() => { setStatus('idle'); setRegisteredMember(null); }}
                    className="mt-8 font-display text-lg bg-yellow-400 text-gray-900 px-8 py-2 rounded-md hover:bg-yellow-300 transition-colors duration-300"
                >
                    Register Another Member
                </button>
            </div>
        )
    }

    return (
        <div className="max-w-lg mx-auto bg-gray-800 p-8 rounded-lg shadow-2xl">
            <h2 className="font-display text-4xl text-center text-yellow-400 mb-2">Join the Club</h2>
            <p className="text-center text-gray-400 mb-8">Fill out your details to get your digital membership card.</p>
            <form onSubmit={handleSubmit} noValidate>
                <div className="mb-6 relative">
                    <label htmlFor="name" className="sr-only">Full Name</label>
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <UserIcon className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                        type="text"
                        name="name"
                        id="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Full Name"
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-3 pl-10 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        required
                    />
                </div>
                <div className="mb-6 relative">
                    <label htmlFor="email" className="sr-only">Email</label>
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <EmailIcon className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                        type="email"
                        name="email"
                        id="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Email Address"
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-3 pl-10 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        required
                    />
                </div>
                <div className="mb-8 relative">
                    <label htmlFor="phone" className="sr-only">Phone Number</label>
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <PhoneIcon className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                        type="tel"
                        name="phone"
                        id="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        placeholder="Phone Number"
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-3 pl-10 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400"
                        required
                    />
                </div>
                
                {error && <p className="text-red-400 text-center mb-4">{error}</p>}
                
                <button
                    type="submit"
                    disabled={status === 'submitting'}
                    className="w-full font-display text-xl bg-yellow-400 text-gray-900 py-3 rounded-md hover:bg-yellow-300 transition-all duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                    {status === 'submitting' && (
                        <svg className="animate-spin h-5 w-5 text-gray-800" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                    )}
                    <span>{status === 'submitting' ? 'CREATING YOUR CARD...' : 'GET MY CARD'}</span>
                </button>
            </form>
        </div>
    );
};

export default RegistrationForm;
