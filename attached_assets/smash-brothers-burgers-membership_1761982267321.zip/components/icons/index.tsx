
export { default as UserIcon } from './UserIcon';
export { default as EmailIcon } from './EmailIcon';
export { default as PhoneIcon } from './PhoneIcon';
export { default as CardIcon } from './CardIcon';
export { default as MoneyIcon } from './MoneyIcon';
export { default as CloseIcon } from './CloseIcon';
