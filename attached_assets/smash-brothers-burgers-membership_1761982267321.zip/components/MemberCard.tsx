
import React, { useEffect, useRef } from 'react';
import { Member } from '../types';

declare var JsBarcode: any;

interface BarcodeProps {
  value: string;
}

const Barcode: React.FC<BarcodeProps> = ({ value }) => {
  const ref = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (ref.current) {
      JsBarcode(ref.current, value, {
        format: "CODE128",
        lineColor: "#000",
        width: 2,
        height: 50,
        displayValue: true,
        fontOptions: "bold",
        fontSize: 16,
        margin: 10
      });
    }
  }, [value]);

  return <svg ref={ref}></svg>;
};

interface MemberCardProps {
    member: Member;
}

const MemberCard: React.FC<MemberCardProps> = ({ member }) => {
    return (
        <div className="w-96 h-60 bg-gradient-to-br from-gray-800 to-black rounded-2xl shadow-2xl p-6 flex flex-col justify-between text-white relative overflow-hidden">
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-yellow-400/10 rounded-full filter blur-xl"></div>
            <div className="absolute -bottom-12 -left-12 w-32 h-32 bg-yellow-400/20 rounded-full filter blur-lg"></div>
            
            <div className="z-10 flex justify-between items-start">
                <div>
                    <p className="font-display text-sm tracking-widest text-yellow-400">MEMBER</p>
                    <h3 className="text-2xl font-bold tracking-wide">{member.name}</h3>
                </div>
                <div className="flex items-center space-x-2">
                    <svg className="w-8 h-8 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.657 7.343A8 8 0 0117.657 18.657z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.879 16.121A3 3 0 1014.12 11.88a3 3 0 00-4.242 4.242z" /></svg>
                    <h2 className="font-display text-2xl tracking-wider">SMASH BROS</h2>
                </div>
            </div>

            <div className="z-10 bg-white p-2 rounded-md flex justify-center items-center">
                 <Barcode value={member.id} />
            </div>
        </div>
    );
};

export default MemberCard;
