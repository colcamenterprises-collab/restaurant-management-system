
import React, { useState } from 'react';
import { Member } from '../types';
import { CloseIcon } from './icons';

interface AddSpendModalProps {
    member: Member;
    onClose: () => void;
    onConfirm: (amount: number) => void;
}

const AddSpendModal: React.FC<AddSpendModalProps> = ({ member, onClose, onConfirm }) => {
    const [amount, setAmount] = useState('');

    const handleConfirm = () => {
        const spendAmount = parseFloat(amount);
        if (!isNaN(spendAmount) && spendAmount > 0) {
            onConfirm(spendAmount);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-gray-800 rounded-lg shadow-2xl p-8 w-full max-w-md" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-display text-3xl text-yellow-400">Add Spend</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                        <CloseIcon className="w-6 h-6"/>
                    </button>
                </div>
                <p className="mb-2 text-gray-300">Adding spend for:</p>
                <p className="text-xl font-bold mb-6">{member.name}</p>

                <div>
                    <label htmlFor="spend-amount" className="block text-sm font-medium text-gray-400 mb-2">
                        Amount (THB)
                    </label>
                    <div className="relative">
                        <input
                            type="number"
                            id="spend-amount"
                            value={amount}
                            onChange={(e) => setAmount(e.target.value)}
                            placeholder="e.g., 550.00"
                            className="w-full bg-gray-700 border border-gray-600 rounded-md py-3 px-4 text-white text-lg focus:outline-none focus:ring-2 focus:ring-yellow-400"
                            autoFocus
                        />
                    </div>
                </div>

                <div className="mt-8 flex justify-end space-x-4">
                    <button 
                        onClick={onClose}
                        className="font-display text-lg bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-500 transition-colors"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={handleConfirm}
                        disabled={!amount || parseFloat(amount) <= 0}
                        className="font-display text-lg bg-yellow-400 text-gray-900 px-6 py-2 rounded-md hover:bg-yellow-300 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed"
                    >
                        Confirm
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AddSpendModal;
